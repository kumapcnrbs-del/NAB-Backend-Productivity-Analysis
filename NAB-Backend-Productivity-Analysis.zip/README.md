# 📊 NAB Backend Process — CSAT, Quality, AHT & Productivity Analysis

**Tool:** Tableau  
**Theme:** Modern Blue Analytics (Blue–White–Grey)  
**Period:** Jan 2024 – Dec 2024  

---

## 🎯 Project Objective
Analyze **Customer Satisfaction (CSAT)**, **Average Handle Time (AHT)**, **Quality**, and **Productivity** metrics from NAB’s backend process to identify performance patterns that improve efficiency and enhance customer experience.

---

## 🧠 Key Business Questions
1. How does productivity vary by team and department?  
2. What’s the relationship between **CSAT and AHT**?  
3. Which teams maintain the best **Quality and Productivity balance**?  
4. How do these metrics trend over time — weekly, monthly, quarterly, and year-to-date?

---

## 📈 Key Metrics (KPIs)
| Category | KPI | Description |
|-----------|------|-------------|
| Productivity | **Productivity Index** | (Productive Hours × Quality × CSAT) / 100 |
| Customer | **CSAT Score** | Customer Satisfaction (1–5 scale) |
| Efficiency | **AHT** | Average Handle Time in minutes |
| Quality | **Quality Score** | QA evaluation percentage |
| Workforce | **Login Hours**, **Breaks**, **Attendance** | Employee operational performance |

---

## 🧩 Dynamic Dashboard Features
- 📆 **Time Selection Parameter:**  
  `Weekly | Monthly | Quarterly | Year-to-Date`  
  (updates all charts dynamically)
- 📊 **Line Charts:**  
  - Monthly **CSAT Trend**  
  - Monthly **Productivity Trend**  
  - **Dual-Axis Line Chart:** CSAT vs AHT  
- 💼 **KPI Cards:** Average CSAT | Quality | AHT | Productivity Index  
- 📋 **Filters:** Department | Manager | Location  
- 🎨 **Theme:** Modern Blue Analytics (Blue #007BFF, Light Grey #E5E7EB, White #FFFFFF)

---

## 🧮 Core Tableau Calculations

**1️⃣ Productivity Index**
```tableau
([Productive_Hours] * [Quality_Score] * [CSAT_Score]) / 100
```

**2️⃣ Efficiency %**
```tableau
([Productive_Hours] / [Login_Hours]) * 100
```

**3️⃣ Dynamic Date Level**
```tableau
CASE [Select Period]
    WHEN "Weekly" THEN DATETRUNC('week', [Date])
    WHEN "Monthly" THEN DATETRUNC('month', [Date])
    WHEN "Quarterly" THEN DATETRUNC('quarter', [Date])
    WHEN "Year-to-Date" THEN DATETRUNC('year', [Date])
END
```

---

## 📊 Example Insights
- Productivity rises with higher **Quality Scores (>90%)** and consistent **CSAT (>4.3)**.  
- **AHT inversely correlates** with CSAT (optimal range 4–5 mins).  
- **Manager Emma Brown’s** team achieved highest performance in Q3 2024.  
- Quality dips in **Account Closure** process led to temporary CSAT drop in mid-2024.  

---

## 📂 Files in This Repository
| File | Description |
|------|--------------|
| `data/nab_backend_productivity_varied.csv` | 10,000-record dataset |
| `docs/NAB_Backend_CSAT_Productivity_Guide.pdf` | Tableau dashboard build guide |
| `docs/tableau_calculations_reference.txt` | Calculated fields and parameters |
| `docs/dashboard_mock_layout.png` | Visual mock of dashboard layout |
| `tableau_dashboard/NAB_Backend_Productivity.twbx` | Tableau packaged workbook |
| `README.md` | Project documentation |

---

## 🪄 How to Use
1. Download this repository or clone it:
   ```bash
   git clone https://github.com/kumapcn/NAB-Backend-Productivity-Analysis.git
   ```
2. Open `nab_backend_productivity_varied.csv` in Tableau.  
3. Create calculated fields and parameter as defined in `tableau_calculations_reference.txt`.  
4. Design the dashboard as shown in `dashboard_mock_layout.png`.  
5. Export or publish the `.twbx` file to Tableau Public.  

---

## 🌐 Portfolio Links
- **GitHub:** [github.com/kumapcn/Tableau-Projects](https://github.com/kumapcn/Tableau-Projects)  
- **Tableau Public:** [public.tableau.com/app/profile/pradeep.kumar1408/vizzes](https://public.tableau.com/app/profile/pradeep.kumar1408/vizzes)  

---

## 🏁 Result
An interactive **Tableau Dashboard** visualizing NAB’s backend process metrics (CSAT, Quality, AHT, and Productivity) across dynamic time periods — perfect for data storytelling, performance analytics, and portfolio showcasing.
